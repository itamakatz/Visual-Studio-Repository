﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace TDC_WPF_Embedded_UI
{
	/// <summary> Application. </summary>
	/// <seealso cref="T:System.Windows.Application"/>
	public partial class App : Application
	{
	}
}
