﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace Generic_Device_WPF_UI
{
	/// <summary> Application. </summary>
	/// <seealso cref="T:System.Windows.Application"/>
	public partial class App : Application
	{
	}
}
